curvegen_cpp.pl --mission=BAT   -xy "GRB 060614" 0.3 10 0.3 1.5 1.51 10 1 '00214805' 171981829.76 
